package control;

import model.BeerExpert;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public class BeerSelect extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String color = request.getParameter("color");
        BeerExpert expert = new BeerExpert();
        List<String> brands = expert.getBrand(color);
        request.setAttribute("result", brands);
        RequestDispatcher view = request.getRequestDispatcher("result.jsp");
        view.forward(request, response);
//        deprecated code from my first trial which was creating the response page from the servlet,
//        instead of forwarding the request to the result.jsp page:

//        String brandNames = "";
//        for (String brand : brands) {
//            brandNames += brand + ", ";
//        }
//        brandNames = brandNames.substring(0, brandNames.length() - 2);
//        out.print("<html>");
//        out.print("<head lang='en-us'>");
//        out.print("<meta charset='UTF-8'>");
//        out.print("<link href='form.css' rel='stylesheet'>");
//        out.print("<title>Beer Advisor</title>");
//        out.print("</head>");
//        out.print("<body>");
//        out.print("<h1>Beer Selection Page</h1>");
//        out.print("<form method='post' action='SelectBeer.do'>");
//        out.print("<div>Select beer characteristics:</div>");
//        out.print("<div>Color:");
//        out.print("<select name='color' size='1'>");
//        out.print("<option value='light' >Light</option>");
//        out.print("<option value='amber'>Amber</option>");
//        out.print("<option value='brown'>Brown</option>");
//        out.print("<option value='dark'>Dark</option>");
//        out.print("</select>");
//        out.print("</div>");
//        out.print("<input type='submit' value='  Submit  '>");
//        out.print("</form>");
//        out.print("<div>Got beer color: " + color + " </div>");
//        out.print("<div>Suggested brands: " + brandNames + "</div>");
//        out.print("</body>");
//        out.print("</html>");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
