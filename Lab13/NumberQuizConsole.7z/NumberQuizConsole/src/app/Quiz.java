package app;

import java.util.ArrayList;
import java.util.List;

public class Quiz {
	
	private int numCorrect = 0;
	private int currentQuestionNumber = 0;
	private List<Question> questions = new ArrayList<Question>();

	public int getNumCorrect() {
		return this.numCorrect;
	}

	public String getCurrentQuestion() {
		return this.questions.get(currentQuestionNumber).questionText;
	}

	public boolean isCorrect(String answer) {
		return this.questions.get(this.currentQuestionNumber).correctAnswer.equals(answer);
	}

	public void scoreAnswer() {
		this.numCorrect++;
		this.currentQuestionNumber++;
	}

	public int getNumQuestions() {
		return this.questions.size();
	}

	public void addQuestion (String questionText, String correctAnswer) {
		this.questions.add(new Question(questionText, correctAnswer));
	}

	private class Question {

		public Question(String questionText, String correctAnswer) {
			this.questionText = questionText;
			this.correctAnswer = correctAnswer;
		}

		private String questionText;
		private String correctAnswer;
	}
}